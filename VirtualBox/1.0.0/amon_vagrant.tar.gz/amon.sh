#!/bin/bash -x

AGRAF_DOCS=/agraf/docs
VAG_BUILD=/vagrant/build
VAG_BIN=$VAG_BUILD/bin
VAG_DOCS=$VAG_BUILD/docs
VAG_MAN=$VAG_BUILD/man

systemctl stop firewalld
systemctl disable firewalld

cp /vagrant/selinux /etc/sysconfig/selinux
cp /vagrant/rpms/mysql80-community-release-el7-3.noarch.rpm /tmp
yum localinstall -y /tmp/mysql80-community-release-el7-3.noarch.rpm

yum install -y docker-engine docker-compose mysql-community-server mysql-community-client 

systemctl enable docker
systemctl start docker
systemctl enable mysqld
systemctl start mysqld

parted /dev/sdb mklabel msdos
parted /dev/sdb -a optimal mkpart primary 1 100%FREE
mkfs.xfs /dev/sdb1
echo "/dev/sdb1 /agraf xfs defaults 0 2" >> /etc/fstab

mkdir /agraf
chmod 777 /agraf
mount /agraf

mkdir -p /agraf/data /agraf/import $AGRAF_DOCS
chmod -R 777 /agraf
chown mysql:mysql /agraf/import

systemctl stop mysqld
cp /vagrant/my.cnf /etc/my.cnf
systemctl start mysqld

# Change MySQL root password.
grep 'temporary password' /var/log/mysqld.log  | sed s'/^.*localhost: /password=/' > /tmp/pwd
echo "[client]" > /root/.my.cnf
cat /tmp/pwd >> /root/.my.cnf

cp /vagrant/agraf_mysql.sql /root
mysql -u root --connect-expired-password < /root/agraf_mysql.sql

rm -f /root/.my.cnf /tmp/pwd

# Create agraf user.
sudo useradd --create-home --shell /bin/bash agraf
sudo passwd agraf <<-END
agraf
agraf
END

cp $VAG_BIN/amon2agraf /usr/local/bin
cp $VAG_DOCS/*html $AGRAF_DOCS
cp $VAG_MAN/*.7 /usr/share/man/man7

chown -R agraf $AGRAF_SCRIPTS $AGRAF_DOCS

mkdir /root/agraf
mkdir /root/agraf/grafana
cp /vagrant/datasource.yaml /root/agraf/grafana/datasource.yaml
cp /vagrant/docker-compose.yaml /root/agraf/docker-compose.yaml
cp /vagrant/mysql.env /root/agraf/mysql.env
cp /vagrant/mysql.json /root/agraf/mysql.json
chmod 755 /root/agraf/docker-compose.yaml 
chmod 755 /root/agraf/mysql.json /root/agraf/mysql.env
chmod 755 /root/agraf/grafana /root/agraf/grafana/datasource.yaml
