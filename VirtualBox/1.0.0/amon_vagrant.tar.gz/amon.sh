#!/bin/bash -x

# Change MySQL root password.
function change_mysql_password {
  grep 'temporary password' /var/log/mysqld.log  | sed s'/^.*localhost: /password=/' > /tmp/pwd
  echo "[client]" > /root/.my.cnf
  cat /tmp/pwd >> /root/.my.cnf

cat /root/.my.cnf

  mkdir /root/agraf
  cp /vagrant/root_mysql.sql /root/agraf/root_mysql.sql
  mysql -u root --connect-expired-password < /root/agraf/root_mysql.sql
  rm /root/agraf/root_mysql.sql

  rm -f /root/.my.cnf /tmp/pwd
}

function create_mysql_database {
  cp /vagrant/root_my_cnf /root/.my.cnf
  cp /vagrant/create_db.sh /root/agraf/create_db.sh
  /root/agraf/create_db.sh $*
}

function vm_created {
  local vm_name=$1

  echo "Installation finished. Please restart this Linux VM:"
  echo "> vagrant halt $vm_name"
  echo "> vagrant up"
}

systemctl stop firewalld
systemctl disable firewalld

cp /vagrant/selinux /etc/sysconfig/selinux
cp /vagrant/rpms/mysql80-community-release-el7-3.noarch.rpm /tmp
yum localinstall -y /tmp/mysql80-community-release-el7-3.noarch.rpm

yum install -y docker-engine docker-compose mysql-community-server mysql-community-client 

systemctl enable docker
systemctl start docker
systemctl enable mysqld
systemctl start mysqld

parted /dev/sdb mklabel msdos
parted /dev/sdb -a optimal mkpart primary 1 100%FREE
mkfs.xfs /dev/sdb1
echo "/dev/sdb1 /agraf xfs defaults 0 2" >> /etc/fstab

mkdir /agraf
chmod 777 /agraf
mount /agraf

mkdir -p /agraf/docs
chmod 777 /agraf/docs

systemctl stop mysqld
cp /vagrant/my.cnf /etc/my.cnf
systemctl start mysqld

change_mysql_password

VAG_BUILD=/vagrant/build
VAG_BIN=$VAG_BUILD/bin
VAG_DOCS=$VAG_BUILD/docs
VAG_MAN=$VAG_BUILD/man

cp $VAG_BIN/amon2agraf /usr/local/bin
cp $VAG_DOCS/*html /agraf/docs
cp $VAG_MAN/*.7 /usr/share/man/man7

mkdir -p /root/agraf/grafana
cp /vagrant/datasource.yaml /root/agraf/grafana/datasource.yaml
cp /vagrant/docker-compose.yaml /root/agraf/docker-compose.yaml
cp /vagrant/mysql.env /root/agraf/mysql.env
cp /vagrant/mysql.json /root/agraf/mysql.json
chmod 755 /root/agraf/docker-compose.yaml 
chmod 755 /root/agraf/mysql.json /root/agraf/mysql.env
chmod 755 /root/agraf/grafana /root/agraf/grafana/datasource.yaml

cp /vagrant/run_*sh /root/agraf
chmod 755 /root/agraf/run_*sh

create_mysql_database grafana Agraf1234! grafana 

vm_created ol7amon1
