#!/bin/bash 

# This container access 2 files in different local directories. That's why
# 2 different volumes are used:
# - /config directory in the container contains the configuration file.
# - /amon directory contains the AMON report.
# The container working directory is set to /config.
# The corresponding files must be located in these directories. The arguments
# must be only file names without any directory path.

CONFIG_DIR=/root/agraf
RUN_DIR=/vagrant/amon

if [ $# -ne 2 ]; then
  echo "Usage: AMON_JSON_File Mysql_Config_File"
  exit 1
fi

AMON_FILE=$1
CONFIG_FILE=$2

cd $CONFIG_DIR

docker run --rm --network host -v $CONFIG_DIR:/config -v $RUN_DIR:/amon asora/agraf_amon2agraf -file /amon/$AMON_FILE -config /config/$CONFIG_FILE -host 127.0.0.1
