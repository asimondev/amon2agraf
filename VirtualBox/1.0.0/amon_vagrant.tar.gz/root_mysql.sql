alter user 'root'@'localhost' identified by 'MyRoot1234!';
quit
