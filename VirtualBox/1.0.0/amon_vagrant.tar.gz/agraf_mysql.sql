alter user 'root'@'localhost' identified by 'MyRoot1234!';
create database grafana;
create user grafana identified with mysql_native_password by 'Agraf1234!';
grant all privileges on grafana.* to `grafana`@`%`;
grant file on *.* to `grafana`@`%`;
quit
