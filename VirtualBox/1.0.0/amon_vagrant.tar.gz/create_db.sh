#!/bin/bash

if [ $# -ne 3 ]; then
  echo "Usage: User Password Database"
  exit 1
fi

MYSQL_USR=$1
MYSQL_PWD=$2
MYSQL_DB=$3

mysql -u root <<End
create database $MYSQL_DB;
create user $MYSQL_USR identified with mysql_native_password by '$MYSQL_PWD';
grant all privileges on ${MYSQL_DB}.* to \`${MYSQL_USR}\`@\`%\`;

quit
End
